import SwiftUI
import WebKit

struct DownloadItem: Identifiable {
    enum State { case running, done, failed }
    let id = UUID()
    var name: String
    var progress: Double = 0
    var state: State = .running
    var fileURL: URL?
}

final class BrowserModel: NSObject, ObservableObject {
    let webView: WKWebView

    @Published var urlText = ""
    @Published var canGoBack = false
    @Published var canGoForward = false
    @Published var isLoading = false
    @Published var progress = 0.0
    @Published var downloads: [DownloadItem] = []

    private var observers: [NSKeyValueObservation] = []
    private var downloadIDs: [ObjectIdentifier: UUID] = [:]
    private var progressObservers: [UUID: NSKeyValueObservation] = [:]

    override init() {
        let config = WKWebViewConfiguration()
        config.defaultWebpagePreferences.preferredContentMode = .desktop
        config.allowsInlineMediaPlayback = true
        webView = WKWebView(frame: .zero, configuration: config)
        webView.customUserAgent =
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36 Edg/124.0.0.0"
        webView.allowsBackForwardNavigationGestures = true
        super.init()
        webView.navigationDelegate = self
        webView.uiDelegate = self

        observers = [
            webView.observe(\.canGoBack) { [weak self] w, _ in
                DispatchQueue.main.async { self?.canGoBack = w.canGoBack }
            },
            webView.observe(\.canGoForward) { [weak self] w, _ in
                DispatchQueue.main.async { self?.canGoForward = w.canGoForward }
            },
            webView.observe(\.isLoading) { [weak self] w, _ in
                DispatchQueue.main.async { self?.isLoading = w.isLoading }
            },
            webView.observe(\.estimatedProgress) { [weak self] w, _ in
                DispatchQueue.main.async { self?.progress = w.estimatedProgress }
            },
            webView.observe(\.url) { [weak self] w, _ in
                DispatchQueue.main.async { self?.urlText = w.url?.absoluteString ?? "" }
            }
        ]
    }

    func load(_ input: String) {
        let text = input.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !text.isEmpty else { return }
        var url: URL?
        if text.contains("://") {
            url = URL(string: text)
        } else if text.contains(".") && !text.contains(" ") {
            url = URL(string: "https://" + text)
        }
        if url == nil {
            var c = URLComponents(string: "https://www.google.com/search")!
            c.queryItems = [URLQueryItem(name: "q", value: text)]
            url = c.url
        }
        if let url { webView.load(URLRequest(url: url)) }
    }

    private func adopt(_ download: WKDownload) {
        download.delegate = self
        let item = DownloadItem(name: download.originalRequest?.url?.lastPathComponent ?? "download")
        downloadIDs[ObjectIdentifier(download)] = item.id
        downloads.insert(item, at: 0)
        progressObservers[item.id] = download.progress.observe(\.fractionCompleted) { [weak self] p, _ in
            let value = p.fractionCompleted
            DispatchQueue.main.async {
                self?.update(item.id) { $0.progress = value }
            }
        }
    }

    private func update(_ id: UUID, _ change: (inout DownloadItem) -> Void) {
        if let i = downloads.firstIndex(where: { $0.id == id }) {
            change(&downloads[i])
        }
    }

    private func finish(_ download: WKDownload, _ state: DownloadItem.State) {
        guard let id = downloadIDs.removeValue(forKey: ObjectIdentifier(download)) else { return }
        update(id) {
            $0.state = state
            if state == .done { $0.progress = 1 }
        }
        progressObservers[id] = nil
    }
}

extension BrowserModel: WKNavigationDelegate {
    func webView(_ webView: WKWebView,
                 decidePolicyFor navigationAction: WKNavigationAction,
                 preferences: WKWebpagePreferences,
                 decisionHandler: @escaping (WKNavigationActionPolicy, WKWebpagePreferences) -> Void) {
        decisionHandler(navigationAction.shouldPerformDownload ? .download : .allow, preferences)
    }

    func webView(_ webView: WKWebView,
                 decidePolicyFor navigationResponse: WKNavigationResponse,
                 decisionHandler: @escaping (WKNavigationResponsePolicy) -> Void) {
        let disposition = (navigationResponse.response as? HTTPURLResponse)?
            .value(forHTTPHeaderField: "Content-Disposition")?.lowercased() ?? ""
        let isDownload = !navigationResponse.canShowMIMEType || disposition.contains("attachment")
        decisionHandler(isDownload ? .download : .allow)
    }

    func webView(_ webView: WKWebView, navigationAction: WKNavigationAction, didBecome download: WKDownload) {
        adopt(download)
    }

    func webView(_ webView: WKWebView, navigationResponse: WKNavigationResponse, didBecome download: WKDownload) {
        adopt(download)
    }
}

extension BrowserModel: WKDownloadDelegate {
    func download(_ download: WKDownload,
                  decideDestinationUsing response: URLResponse,
                  suggestedFilename: String,
                  completionHandler: @escaping (URL?) -> Void) {
        let dest = PrefixManager.shared.uniqueURL(in: PrefixManager.shared.downloads, name: suggestedFilename)
        if let id = downloadIDs[ObjectIdentifier(download)] {
            update(id) {
                $0.name = dest.lastPathComponent
                $0.fileURL = dest
            }
        }
        completionHandler(dest)
    }

    func downloadDidFinish(_ download: WKDownload) {
        finish(download, .done)
    }

    func download(_ download: WKDownload, didFailWithError error: Error, resumeData: Data?) {
        finish(download, .failed)
    }
}

extension BrowserModel: WKUIDelegate {
    func webView(_ webView: WKWebView,
                 createWebViewWith configuration: WKWebViewConfiguration,
                 for navigationAction: WKNavigationAction,
                 windowFeatures: WKWindowFeatures) -> WKWebView? {
        if navigationAction.targetFrame == nil {
            webView.load(navigationAction.request)
        }
        return nil
    }
}

struct WebHost: UIViewRepresentable {
    let webView: WKWebView
    func makeUIView(context: Context) -> WKWebView { webView }
    func updateUIView(_ uiView: WKWebView, context: Context) {}
}

struct BrowserView: View {
    @StateObject private var model = BrowserModel()
    @EnvironmentObject var wm: WindowManager
    @State private var showDownloads = false

    var body: some View {
        VStack(spacing: 0) {
            HStack(spacing: 10) {
                Button { model.webView.goBack() } label: { Image(systemName: "chevron.left") }
                    .disabled(!model.canGoBack)
                Button { model.webView.goForward() } label: { Image(systemName: "chevron.right") }
                    .disabled(!model.canGoForward)
                Button {
                    model.isLoading ? model.webView.stopLoading() : model.webView.reload()
                } label: {
                    Image(systemName: model.isLoading ? "xmark" : "arrow.clockwise")
                }

                TextField("Search or enter address", text: $model.urlText)
                    .textFieldStyle(.roundedBorder)
                    .textInputAutocapitalization(.never)
                    .autocorrectionDisabled()
                    .keyboardType(.webSearch)
                    .onSubmit { model.load(model.urlText) }

                Button { showDownloads.toggle() } label: {
                    Image(systemName: "arrow.down.circle")
                }
                .popover(isPresented: $showDownloads) {
                    DownloadsList(model: model) {
                        showDownloads = false
                        wm.open(.explorer, startURL: PrefixManager.shared.downloads)
                    }
                    .presentationCompactAdaptation(.popover)
                }
            }
            .padding(8)
            .background(.bar)

            if model.isLoading {
                ProgressView(value: model.progress)
                    .progressViewStyle(.linear)
            }

            WebHost(webView: model.webView)
        }
        .onAppear {
            if model.webView.url == nil { model.load("https://www.google.com") }
        }
    }
}

struct DownloadsList: View {
    @ObservedObject var model: BrowserModel
    let reveal: () -> Void

    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            Text("Downloads").font(.headline)
            if model.downloads.isEmpty {
                Text("Nothing downloaded yet.")
                    .font(.footnote)
                    .foregroundStyle(.secondary)
            } else {
                ForEach(model.downloads) { item in
                    VStack(alignment: .leading, spacing: 4) {
                        Text(item.name).font(.system(size: 13)).lineLimit(1)
                        switch item.state {
                        case .running:
                            ProgressView(value: item.progress)
                        case .done:
                            Text("Saved to Downloads").font(.caption).foregroundStyle(.green)
                        case .failed:
                            Text("Failed").font(.caption).foregroundStyle(.red)
                        }
                    }
                }
            }
            Button("Show in File Explorer", action: reveal)
                .font(.system(size: 13))
        }
        .padding(14)
        .frame(width: 280)
    }
}
