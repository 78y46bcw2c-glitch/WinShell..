import Foundation
import Combine
import Darwin

final class PrefixManager {
    static let shared = PrefixManager()

    let root: URL
    let driveC: URL
    var desktop: URL { driveC.appendingPathComponent("Users/User/Desktop", isDirectory: true) }
    var documents: URL { driveC.appendingPathComponent("Users/User/Documents", isDirectory: true) }
    var downloads: URL { driveC.appendingPathComponent("Users/User/Downloads", isDirectory: true) }

    private init() {
        let docs = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
        root = docs.appendingPathComponent("WinShell", isDirectory: true)
        driveC = root.appendingPathComponent("drive_c", isDirectory: true)
        let folders = [
            "Users/User/Desktop", "Users/User/Documents", "Users/User/Downloads",
            "Program Files", "Program Files (x86)", "Windows/System32"
        ]
        for f in folders {
            try? FileManager.default.createDirectory(
                at: driveC.appendingPathComponent(f, isDirectory: true),
                withIntermediateDirectories: true
            )
        }
    }

    func windowsPath(_ url: URL) -> String {
        let base = driveC.resolvingSymlinksInPath().path
        let path = url.resolvingSymlinksInPath().path
        guard path.hasPrefix(base) else { return path }
        let rel = String(path.dropFirst(base.count)).replacingOccurrences(of: "/", with: "\\")
        return "C:" + (rel.isEmpty ? "\\" : rel)
    }

    func uniqueURL(in dir: URL, name: String) -> URL {
        let clean = name.isEmpty ? "download" : name.replacingOccurrences(of: "/", with: "_")
        var candidate = dir.appendingPathComponent(clean)
        let ext = candidate.pathExtension
        let stem = candidate.deletingPathExtension().lastPathComponent
        var n = 1
        while FileManager.default.fileExists(atPath: candidate.path) {
            let newName = ext.isEmpty ? "\(stem) (\(n))" : "\(stem) (\(n)).\(ext)"
            candidate = dir.appendingPathComponent(newName)
            n += 1
        }
        return candidate
    }
}

final class JITMonitor: ObservableObject {
    @Published var enabled = JITMonitor.isDebuggerAttached()
    private var timer: Timer?

    init() {
        timer = Timer.scheduledTimer(withTimeInterval: 2, repeats: true) { [weak self] _ in
            self?.enabled = Self.isDebuggerAttached()
        }
    }

    static func isDebuggerAttached() -> Bool {
        var info = kinfo_proc()
        var size = MemoryLayout<kinfo_proc>.stride
        var mib: [Int32] = [CTL_KERN, KERN_PROC, KERN_PROC_PID, getpid()]
        let result = sysctl(&mib, UInt32(mib.count), &info, &size, nil, 0)
        return result == 0 && (info.kp_proc.p_flag & P_TRACED) != 0
    }
}

enum EngineError: LocalizedError {
    case jitRequired
    case notIntegrated

    var errorDescription: String? {
        switch self {
        case .jitRequired:
            return "JIT is off. Open StikDebug, enable JIT for WinShell, then try again."
        case .notIntegrated:
            return "The Madeira engine isn't linked yet. See README step 5."
        }
    }
}

protocol WindowsEngine {
    var name: String { get }
    func launch(exe: URL) async throws
}

struct MadeiraEngine: WindowsEngine {
    let name = "Madeira (Wine + FEX-Emu + DXMT)"

    func launch(exe: URL) async throws {
        guard JITMonitor.isDebuggerAttached() else { throw EngineError.jitRequired }
        let winPath = PrefixManager.shared.windowsPath(exe)
        _ = winPath
        throw EngineError.notIntegrated
    }
}

enum Engine {
    static let shared: WindowsEngine = MadeiraEngine()
}
