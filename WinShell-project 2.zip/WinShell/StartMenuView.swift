import SwiftUI

struct StartMenuView: View {
    @EnvironmentObject var wm: WindowManager
    @Binding var show: Bool

    @State private var query = ""
    @State private var recent: [URL] = []

    private var results: [AppKind] {
        let q = query.trimmingCharacters(in: .whitespaces).lowercased()
        return q.isEmpty ? AppKind.allCases : AppKind.allCases.filter { $0.title.lowercased().contains(q) }
    }

    var body: some View {
        VStack(alignment: .leading, spacing: 14) {
            HStack(spacing: 8) {
                Image(systemName: "magnifyingglass").foregroundStyle(.secondary)
                TextField("Search for apps", text: $query)
                    .textInputAutocapitalization(.never)
                    .autocorrectionDisabled()
            }
            .padding(10)
            .background(Color.white.opacity(0.6), in: RoundedRectangle(cornerRadius: 8))

            Text(query.isEmpty ? "Pinned" : "Results")
                .font(.system(size: 13, weight: .semibold))

            if results.isEmpty {
                Text("No results").font(.footnote).foregroundStyle(.secondary)
            } else {
                LazyVGrid(columns: Array(repeating: GridItem(.flexible()), count: 4), spacing: 12) {
                    ForEach(results) { kind in
                        Button {
                            wm.open(kind)
                            show = false
                        } label: {
                            VStack(spacing: 6) {
                                Image(systemName: kind.icon)
                                    .font(.system(size: 24))
                                    .foregroundStyle(kind.tint)
                                    .frame(width: 48, height: 48)
                                    .background(Color.white.opacity(0.6), in: RoundedRectangle(cornerRadius: 10))
                                Text(kind.title)
                                    .font(.system(size: 11))
                                    .foregroundStyle(.primary)
                                    .lineLimit(1)
                            }
                        }
                        .buttonStyle(.plain)
                    }
                }
            }

            if query.isEmpty {
                Text("Recommended")
                    .font(.system(size: 13, weight: .semibold))
                if recent.isEmpty {
                    Text("Downloaded files will show up here.")
                        .font(.footnote)
                        .foregroundStyle(.secondary)
                } else {
                    ForEach(recent, id: \.self) { url in
                        Button {
                            wm.open(.explorer, startURL: PrefixManager.shared.downloads)
                            show = false
                        } label: {
                            HStack(spacing: 10) {
                                Image(systemName: "doc.fill").foregroundStyle(.blue)
                                Text(url.lastPathComponent)
                                    .font(.system(size: 12))
                                    .lineLimit(1)
                                Spacer()
                            }
                        }
                        .buttonStyle(.plain)
                    }
                }
            }

            Divider()

            HStack {
                Image(systemName: "person.crop.circle.fill").font(.system(size: 22)).foregroundStyle(.secondary)
                Text("User").font(.system(size: 13))
                Spacer()
                Image(systemName: "power")
                    .font(.system(size: 14))
                    .foregroundStyle(.secondary)
            }
        }
        .padding(16)
        .frame(width: 360)
        .background(.regularMaterial, in: RoundedRectangle(cornerRadius: 14, style: .continuous))
        .overlay(RoundedRectangle(cornerRadius: 14, style: .continuous).stroke(Color.black.opacity(0.1)))
        .shadow(color: .black.opacity(0.3), radius: 20, y: 8)
        .onAppear(perform: loadRecent)
    }

    private func loadRecent() {
        let dir = PrefixManager.shared.downloads
        let keys: [URLResourceKey] = [.contentModificationDateKey]
        let files = (try? FileManager.default.contentsOfDirectory(
            at: dir, includingPropertiesForKeys: keys, options: [.skipsHiddenFiles]
        )) ?? []
        recent = files
            .sorted {
                let a = (try? $0.resourceValues(forKeys: Set(keys)).contentModificationDate) ?? .distantPast
                let b = (try? $1.resourceValues(forKeys: Set(keys)).contentModificationDate) ?? .distantPast
                return a > b
            }
            .prefix(3)
            .map { $0 }
    }
}
