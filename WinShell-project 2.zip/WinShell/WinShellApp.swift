import SwiftUI

@main
struct WinShellApp: App {
    @StateObject private var wm = WindowManager()
    @StateObject private var jit = JITMonitor()

    var body: some Scene {
        WindowGroup {
            DesktopView()
                .environmentObject(wm)
                .environmentObject(jit)
                .statusBarHidden()
                .persistentSystemOverlays(.hidden)
                .preferredColorScheme(.light)
        }
    }
}
