import SwiftUI

struct SettingsView: View {
    @EnvironmentObject var jit: JITMonitor

    var body: some View {
        Form {
            Section("System") {
                row("Engine", Engine.shared.name)
                HStack {
                    Text("JIT")
                    Spacer()
                    Label(jit.enabled ? "Enabled" : "Disabled",
                          systemImage: jit.enabled ? "checkmark.circle.fill" : "exclamationmark.triangle.fill")
                        .foregroundStyle(jit.enabled ? .green : .orange)
                        .font(.system(size: 13))
                }
                if !jit.enabled {
                    Text("Open StikDebug, pick WinShell, and enable JIT. Then return here.")
                        .font(.footnote)
                        .foregroundStyle(.secondary)
                }
            }

            Section("Storage") {
                row("C: drive", PrefixManager.shared.windowsPath(PrefixManager.shared.driveC))
                Text(PrefixManager.shared.driveC.path)
                    .font(.system(size: 10, design: .monospaced))
                    .foregroundStyle(.secondary)
                    .textSelection(.enabled)
                Text("Files you download appear in the Files app under On My iPhone > WinShell.")
                    .font(.footnote)
                    .foregroundStyle(.secondary)
            }

            Section("About") {
                row("Version", "0.1.0")
                row("Shell", "WinShell")
            }
        }
        .scrollContentBackground(.hidden)
    }

    private func row(_ title: String, _ value: String) -> some View {
        HStack {
            Text(title)
            Spacer()
            Text(value)
                .font(.system(size: 13))
                .foregroundStyle(.secondary)
                .multilineTextAlignment(.trailing)
        }
    }
}
