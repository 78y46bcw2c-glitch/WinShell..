import SwiftUI

struct WindowView: View {
    @EnvironmentObject var wm: WindowManager
    let id: UUID

    @State private var lastDrag: CGSize = .zero
    @State private var lastResize: CGSize = .zero

    var body: some View {
        if let w = wm.window(id) {
            let f = wm.effectiveFrame(w)
            let focused = wm.focusedID == id

            VStack(spacing: 0) {
                titleBar(w, focused: focused)
                content(w)
                    .frame(maxWidth: .infinity, maxHeight: .infinity)
            }
            .frame(width: f.width, height: f.height)
            .background(.regularMaterial)
            .clipShape(RoundedRectangle(cornerRadius: w.maximized ? 0 : 10, style: .continuous))
            .overlay(
                RoundedRectangle(cornerRadius: w.maximized ? 0 : 10, style: .continuous)
                    .stroke(focused ? Color.blue.opacity(0.35) : Color.black.opacity(0.12), lineWidth: 1)
            )
            .overlay(alignment: .bottomTrailing) {
                if !w.maximized {
                    Image(systemName: "chevron.down.right")
                        .font(.system(size: 10, weight: .bold))
                        .foregroundStyle(.secondary)
                        .frame(width: 30, height: 30)
                        .contentShape(Rectangle())
                        .gesture(
                            DragGesture(coordinateSpace: .global)
                                .onChanged { v in
                                    let d = CGSize(
                                        width: v.translation.width - lastResize.width,
                                        height: v.translation.height - lastResize.height
                                    )
                                    lastResize = v.translation
                                    wm.resize(id, by: d)
                                }
                                .onEnded { _ in lastResize = .zero }
                        )
                }
            }
            .shadow(color: .black.opacity(focused ? 0.35 : 0.15), radius: focused ? 18 : 8, y: 6)
            .position(x: f.midX, y: f.midY)
            .zIndex(Double(w.z))
            .opacity(w.minimized ? 0 : 1)
            .allowsHitTesting(!w.minimized)
            .simultaneousGesture(TapGesture().onEnded { wm.focus(id) })
        }
    }

    private func titleBar(_ w: AppWindow, focused: Bool) -> some View {
        HStack(spacing: 0) {
            HStack(spacing: 8) {
                Image(systemName: w.kind.icon)
                    .foregroundStyle(w.kind.tint)
                Text(w.kind.title)
                    .font(.system(size: 13))
                    .foregroundStyle(focused ? .primary : .secondary)
                Spacer()
            }
            .padding(.leading, 12)
            .frame(height: 34)
            .contentShape(Rectangle())
            .onTapGesture(count: 2) { wm.toggleMaximize(id) }
            .gesture(
                DragGesture(coordinateSpace: .global)
                    .onChanged { v in
                        wm.focus(id)
                        let d = CGSize(
                            width: v.translation.width - lastDrag.width,
                            height: v.translation.height - lastDrag.height
                        )
                        lastDrag = v.translation
                        wm.move(id, by: d)
                    }
                    .onEnded { _ in lastDrag = .zero }
            )

            chromeButton("minus") { wm.minimize(id) }
            chromeButton(w.maximized ? "square.on.square" : "square") { wm.toggleMaximize(id) }
            chromeButton("xmark", danger: true) { wm.close(id) }
        }
        .frame(height: 34)
        .background(Color.white.opacity(0.5))
    }

    private func chromeButton(_ symbol: String, danger: Bool = false, action: @escaping () -> Void) -> some View {
        Button(action: action) {
            Image(systemName: symbol)
                .font(.system(size: 11, weight: .medium))
                .foregroundStyle(.primary)
                .frame(width: 44, height: 34)
                .contentShape(Rectangle())
        }
        .buttonStyle(.plain)
    }

    @ViewBuilder
    private func content(_ w: AppWindow) -> some View {
        switch w.kind {
        case .browser: BrowserView()
        case .explorer: ExplorerView(start: w.startURL)
        case .settings: SettingsView()
        }
    }
}
