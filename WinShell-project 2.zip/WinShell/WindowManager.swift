import SwiftUI

enum AppKind: String, CaseIterable, Identifiable {
    case browser, explorer, settings

    var id: String { rawValue }

    var title: String {
        switch self {
        case .browser: "Browser"
        case .explorer: "File Explorer"
        case .settings: "Settings"
        }
    }

    var icon: String {
        switch self {
        case .browser: "globe"
        case .explorer: "folder.fill"
        case .settings: "gearshape.fill"
        }
    }

    var tint: Color {
        switch self {
        case .browser: .blue
        case .explorer: .yellow
        case .settings: .gray
        }
    }

    var defaultSize: CGSize {
        switch self {
        case .browser: CGSize(width: 820, height: 520)
        case .explorer: CGSize(width: 640, height: 420)
        case .settings: CGSize(width: 520, height: 460)
        }
    }
}

struct AppWindow: Identifiable {
    let id = UUID()
    var kind: AppKind
    var frame: CGRect
    var z: Int
    var minimized = false
    var maximized = false
    var startURL: URL?
}

final class WindowManager: ObservableObject {
    @Published var windows: [AppWindow] = []
    @Published var focusedID: UUID?
    @Published var desktop: CGSize = .zero

    private var zTop = 0
    private var spawned = 0

    func window(_ id: UUID) -> AppWindow? { windows.first { $0.id == id } }
    private func index(_ id: UUID) -> Int? { windows.firstIndex { $0.id == id } }

    func open(_ kind: AppKind, startURL: URL? = nil) {
        let size = kind.defaultSize
        let w = min(size.width, max(desktop.width - 24, 300))
        let h = min(size.height, max(desktop.height - 24, 220))
        let offset = CGFloat(spawned % 6) * 30
        spawned += 1
        zTop += 1
        var win = AppWindow(
            kind: kind,
            frame: CGRect(x: 20 + offset, y: 16 + offset, width: w, height: h),
            z: zTop,
            startURL: startURL
        )
        win.maximized = desktop.width < 700
        windows.append(win)
        focusedID = win.id
    }

    func focus(_ id: UUID) {
        guard let i = index(id) else { return }
        zTop += 1
        windows[i].z = zTop
        windows[i].minimized = false
        focusedID = id
    }

    func close(_ id: UUID) {
        windows.removeAll { $0.id == id }
        if focusedID == id {
            focusedID = windows.filter { !$0.minimized }.max { $0.z < $1.z }?.id
        }
    }

    func minimize(_ id: UUID) {
        guard let i = index(id) else { return }
        windows[i].minimized = true
        if focusedID == id { focusedID = nil }
    }

    func toggleMaximize(_ id: UUID) {
        guard let i = index(id) else { return }
        windows[i].maximized.toggle()
    }

    func taskbarTap(_ kind: AppKind) {
        let ofKind = windows.filter { $0.kind == kind }
        guard let latest = ofKind.max(by: { $0.z < $1.z }) else {
            open(kind)
            return
        }
        if latest.minimized || focusedID != latest.id {
            focus(latest.id)
        } else {
            minimize(latest.id)
        }
    }

    func move(_ id: UUID, by d: CGSize) {
        guard let i = index(id), !windows[i].maximized else { return }
        windows[i].frame.origin.x += d.width
        windows[i].frame.origin.y = max(0, windows[i].frame.origin.y + d.height)
    }

    func resize(_ id: UUID, by d: CGSize) {
        guard let i = index(id), !windows[i].maximized else { return }
        windows[i].frame.size.width = max(300, windows[i].frame.width + d.width)
        windows[i].frame.size.height = max(220, windows[i].frame.height + d.height)
    }

    func effectiveFrame(_ w: AppWindow) -> CGRect {
        w.maximized ? CGRect(origin: .zero, size: desktop) : w.frame
    }
}
