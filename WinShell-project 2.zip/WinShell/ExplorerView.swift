import SwiftUI

struct FileEntry: Identifiable {
    let url: URL
    let isDirectory: Bool
    let size: Int64
    let modified: Date?
    var id: URL { url }
    var name: String { url.lastPathComponent }
    var isExecutable: Bool { ["exe", "msi", "bat", "cmd"].contains(url.pathExtension.lowercased()) }
}

final class ExplorerModel: ObservableObject {
    @Published var dir: URL
    @Published var entries: [FileEntry] = []
    @Published var message: String?

    private var history: [URL] = []
    private let prefix = PrefixManager.shared

    init(start: URL?) {
        dir = start ?? PrefixManager.shared.downloads
        reload()
    }

    var pathText: String { prefix.windowsPath(dir) }

    var canGoUp: Bool {
        dir.resolvingSymlinksInPath().path != prefix.driveC.resolvingSymlinksInPath().path
    }

    func reload() {
        let keys: [URLResourceKey] = [.isDirectoryKey, .fileSizeKey, .contentModificationDateKey]
        let urls = (try? FileManager.default.contentsOfDirectory(
            at: dir, includingPropertiesForKeys: keys, options: [.skipsHiddenFiles]
        )) ?? []
        entries = urls.map { u in
            let v = try? u.resourceValues(forKeys: Set(keys))
            return FileEntry(
                url: u,
                isDirectory: v?.isDirectory ?? false,
                size: Int64(v?.fileSize ?? 0),
                modified: v?.contentModificationDate
            )
        }
        .sorted {
            if $0.isDirectory != $1.isDirectory { return $0.isDirectory }
            return $0.name.localizedCaseInsensitiveCompare($1.name) == .orderedAscending
        }
    }

    func go(_ url: URL) {
        history.append(dir)
        dir = url
        reload()
    }

    func back() {
        guard let previous = history.popLast() else { return }
        dir = previous
        reload()
    }

    func up() {
        guard canGoUp else { return }
        go(dir.deletingLastPathComponent())
    }

    func delete(_ entry: FileEntry) {
        do {
            try FileManager.default.removeItem(at: entry.url)
            reload()
        } catch {
            message = error.localizedDescription
        }
    }

    func launch(_ entry: FileEntry) {
        Task { @MainActor in
            do {
                try await Engine.shared.launch(exe: entry.url)
            } catch {
                message = error.localizedDescription
            }
        }
    }
}

struct ExplorerView: View {
    @StateObject private var model: ExplorerModel

    init(start: URL?) {
        _model = StateObject(wrappedValue: ExplorerModel(start: start))
    }

    var body: some View {
        VStack(spacing: 0) {
            HStack(spacing: 12) {
                Button { model.back() } label: { Image(systemName: "chevron.left") }
                Button { model.up() } label: { Image(systemName: "arrow.up") }
                    .disabled(!model.canGoUp)
                Button { model.reload() } label: { Image(systemName: "arrow.clockwise") }

                Text(model.pathText)
                    .font(.system(size: 12, design: .monospaced))
                    .lineLimit(1)
                    .truncationMode(.head)
                    .padding(.horizontal, 10)
                    .padding(.vertical, 6)
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .background(Color.white.opacity(0.6), in: RoundedRectangle(cornerRadius: 6))

                Menu {
                    Button("This PC") { model.go(PrefixManager.shared.driveC) }
                    Button("Desktop") { model.go(PrefixManager.shared.desktop) }
                    Button("Documents") { model.go(PrefixManager.shared.documents) }
                    Button("Downloads") { model.go(PrefixManager.shared.downloads) }
                } label: {
                    Image(systemName: "star")
                }
            }
            .padding(8)
            .background(.bar)

            if model.entries.isEmpty {
                Spacer()
                Text("This folder is empty.")
                    .font(.footnote)
                    .foregroundStyle(.secondary)
                Spacer()
            } else {
                List(model.entries) { entry in
                    Button {
                        if entry.isDirectory {
                            model.go(entry.url)
                        } else if entry.isExecutable {
                            model.launch(entry)
                        } else {
                            model.message = "No app is associated with .\(entry.url.pathExtension) files yet."
                        }
                    } label: {
                        HStack(spacing: 12) {
                            Image(systemName: icon(for: entry))
                                .font(.system(size: 20))
                                .foregroundStyle(entry.isDirectory ? .yellow : (entry.isExecutable ? .blue : .gray))
                                .frame(width: 26)
                            VStack(alignment: .leading, spacing: 2) {
                                Text(entry.name).font(.system(size: 14)).lineLimit(1)
                                Text(detail(for: entry)).font(.caption).foregroundStyle(.secondary)
                            }
                            Spacer()
                        }
                    }
                    .buttonStyle(.plain)
                    .contextMenu {
                        if entry.isExecutable {
                            Button("Run", systemImage: "play.fill") { model.launch(entry) }
                        }
                        Button("Delete", systemImage: "trash", role: .destructive) { model.delete(entry) }
                    }
                }
                .listStyle(.plain)
            }
        }
        .alert(
            "File Explorer",
            isPresented: Binding(get: { model.message != nil }, set: { if !$0 { model.message = nil } })
        ) {
            Button("OK", role: .cancel) {}
        } message: {
            Text(model.message ?? "")
        }
    }

    private func icon(for e: FileEntry) -> String {
        if e.isDirectory { return "folder.fill" }
        if e.isExecutable { return "macwindow" }
        return "doc.fill"
    }

    private func detail(for e: FileEntry) -> String {
        if e.isDirectory { return "File folder" }
        let size = ByteCountFormatter.string(fromByteCount: e.size, countStyle: .file)
        return e.isExecutable ? "Application · \(size)" : size
    }
}
