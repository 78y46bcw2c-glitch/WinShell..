import SwiftUI

struct DesktopView: View {
    @EnvironmentObject var wm: WindowManager
    @State private var showStart = false

    var body: some View {
        VStack(spacing: 0) {
            GeometryReader { geo in
                ZStack(alignment: .topLeading) {
                    Wallpaper()
                        .onTapGesture {
                            showStart = false
                            wm.focusedID = nil
                        }

                    DesktopIcons()

                    ForEach(wm.windows) { w in
                        WindowView(id: w.id)
                    }

                    if showStart {
                        StartMenuView(show: $showStart)
                            .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .bottom)
                            .padding(.bottom, 10)
                            .zIndex(100_000)
                    }
                }
                .clipped()
                .onAppear { wm.desktop = geo.size }
                .onChange(of: geo.size) { _, newSize in wm.desktop = newSize }
            }
            TaskbarView(showStart: $showStart)
        }
        .background(Color.black)
    }
}

struct Wallpaper: View {
    var body: some View {
        ZStack {
            LinearGradient(
                colors: [
                    Color(red: 0.02, green: 0.08, blue: 0.30),
                    Color(red: 0.08, green: 0.35, blue: 0.85),
                    Color(red: 0.55, green: 0.78, blue: 1.0)
                ],
                startPoint: .bottomLeading,
                endPoint: .topTrailing
            )
            RadialGradient(
                colors: [Color.white.opacity(0.35), Color.clear],
                center: .center,
                startRadius: 10,
                endRadius: 320
            )
        }
        .contentShape(Rectangle())
    }
}

struct DesktopIcons: View {
    @EnvironmentObject var wm: WindowManager

    var body: some View {
        VStack(spacing: 14) {
            ForEach(AppKind.allCases) { kind in
                VStack(spacing: 4) {
                    Image(systemName: kind.icon)
                        .font(.system(size: 28))
                        .foregroundStyle(kind.tint)
                        .frame(width: 54, height: 54)
                        .background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 12, style: .continuous))
                    Text(kind.title)
                        .font(.system(size: 11))
                        .foregroundStyle(.white)
                        .shadow(radius: 2)
                }
                .frame(width: 84)
                .onTapGesture(count: 2) { wm.open(kind) }
            }
        }
        .padding(12)
    }
}

struct TaskbarView: View {
    @EnvironmentObject var wm: WindowManager
    @EnvironmentObject var jit: JITMonitor
    @Binding var showStart: Bool

    var body: some View {
        ZStack {
            HStack(spacing: 4) {
                taskButton(icon: "square.grid.2x2.fill", tint: .blue, running: false, active: showStart) {
                    showStart.toggle()
                }
                ForEach(AppKind.allCases) { kind in
                    let running = wm.windows.contains { $0.kind == kind }
                    let active = wm.windows.contains { $0.id == wm.focusedID && $0.kind == kind }
                    taskButton(icon: kind.icon, tint: kind.tint, running: running, active: active) {
                        showStart = false
                        wm.taskbarTap(kind)
                    }
                }
            }

            HStack {
                Spacer()
                HStack(spacing: 8) {
                    Circle()
                        .fill(jit.enabled ? Color.green : Color.orange)
                        .frame(width: 8, height: 8)
                    Image(systemName: "wifi")
                        .font(.system(size: 12))
                    TimelineView(.periodic(from: .now, by: 30)) { ctx in
                        VStack(alignment: .trailing, spacing: 0) {
                            Text(ctx.date, format: .dateTime.hour().minute())
                            Text(ctx.date, format: .dateTime.month(.defaultDigits).day().year())
                        }
                        .font(.system(size: 10))
                    }
                }
                .padding(.trailing, 12)
            }
        }
        .frame(height: 48)
        .background(.regularMaterial)
        .overlay(alignment: .top) {
            Rectangle().fill(Color.black.opacity(0.1)).frame(height: 0.5)
        }
    }

    private func taskButton(icon: String, tint: Color, running: Bool, active: Bool, action: @escaping () -> Void) -> some View {
        Button(action: action) {
            VStack(spacing: 3) {
                Image(systemName: icon)
                    .font(.system(size: 20))
                    .foregroundStyle(tint)
                    .frame(width: 40, height: 32)
                    .background(active ? Color.white.opacity(0.55) : Color.clear, in: RoundedRectangle(cornerRadius: 6))
                Capsule()
                    .fill(running ? Color.blue : Color.clear)
                    .frame(width: active ? 14 : 6, height: 3)
            }
        }
        .buttonStyle(.plain)
    }
}
