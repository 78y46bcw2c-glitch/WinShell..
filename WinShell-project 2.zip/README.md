# WinShell

A Windows 11 style desktop shell for iOS: taskbar, Start menu, draggable windows, a browser whose downloads land in a Windows-style `C:\Users\User\Downloads`, and a File Explorer. The Madeira engine (Wine + FEX-Emu + DXMT) plugs in through `Core.swift`.

## Get the IPA (no Mac needed)
1. Create a new GitHub repo and upload everything in this folder (keep the `.github` folder).
2. Open the repo's **Actions** tab. The "Build unsigned IPA" workflow runs on every push, or run it by hand with **Run workflow**.
3. When it finishes, open the run and download **WinShell-ipa** from Artifacts. Unzip it to get `WinShell.ipa`.
4. Sideload `WinShell.ipa` with SideStore or AltStore (they sign it with your Apple ID).
5. Open StikDebug, select WinShell, and enable JIT. The dot in the taskbar tray turns green when JIT is on.

If the build fails, open the failed step in the run log and send me the error lines.

## Link the engine (later)
Implement `MadeiraEngine.launch(exe:)` in `Core.swift` by calling into your fork of Madeira. Keep the fork GPL-3.0 compatible.
